<?php

/*
 * Plugin Name:       Super Floating and Flying Menu
 * Plugin URI:        https://demo.hashthemes.com/super-floating-and-flying-menu/
 * Description:       Adds floating, side panel, popup and navigation icon menus
 * Version:           2.4.6
 * Author:            HashThemes
 * Author URI:        https://hashthemes.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       super-floating-flying-menu
 * Domain Path:       /languages
 */

function run_super_floating_flying_menu() {

}

run_super_floating_flying_menu();

